<?php 
ini_set('session.name', 'privateplc_login');
ini_set('session.use_trans_sid', '0');
ini_set('session.use_cookies' , '1' );
ini_set('session.use_only_cookies' , '1');
ini_set('date.timezone', 'Europe/Berlin');
?>
