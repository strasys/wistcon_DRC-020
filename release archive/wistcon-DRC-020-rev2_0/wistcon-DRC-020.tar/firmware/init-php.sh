#!/bin/sh
#This shell script should activiate the composer / DNS Service 
#for EL-100-020-001 DIN-Rail-controller
# strasys.at
# Johannes Strasser
# May, 21st 2017

/usr/bin/php /var/www/startupSetting.php

